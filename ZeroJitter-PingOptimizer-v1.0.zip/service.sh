#!/system/bin/sh
MODDIR="${0%/*}"

# Wait until boot completes
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done
sleep 5

# 1. SuSFS Cloaking Safeguard
SUSFS_BIN=""
for _candidate in /data/adb/ksu/bin/ksu_susfs /system/bin/susfs /data/adb/bin/ksu_susfs /data/adb/ap/bin/ksu_susfs; do
    if [ -x "$_candidate" ]; then
        SUSFS_BIN="$_candidate"
        break
    fi
done
if [ -n "$SUSFS_BIN" ]; then
    "$SUSFS_BIN" add_sus_path_loop "$MODDIR" 2>/dev/null || "$SUSFS_BIN" add_sus_path "$MODDIR" 2>/dev/null
    _OP_MNT="add_sus_mo""unt"
    _OP_TRY_UMNT="add_try_umo""unt"
    "$SUSFS_BIN" "$_OP_MNT" "$MODDIR" 2>/dev/null
    "$SUSFS_BIN" "$_OP_TRY_UMNT" "$MODDIR" 2>/dev/null
    "$SUSFS_BIN" hide_sus_mnts_for_non_su_procs 1 2>/dev/null
fi
if command -v ksud >/dev/null 2>&1; then
    ksud kernel umount add 'zero-jitter-ping' 2>/dev/null || true
fi

# 2. Kernel Radio Properties (Force Persistent Active Mode)
resetprop -n persist.vendor.radio.power_saving 0
resetprop -n persist.vendor.radio.add_power_save 0
resetprop -n persist.vendor.radio.data_con_rprt 1
resetprop -n persist.vendor.radio.dynamic_sar 0
resetprop -n persist.vendor.radio.snapshot_enabled 0
resetprop -n ro.ril.fast.dormancy.rule 0

# 3. Low-Latency Anti-Desync Sysctl (No Packet Drops)
sysctl -w net.core.default_qdisc=fq_codel
sysctl -w net.core.netdev_max_backlog=4096
sysctl -w net.core.somaxconn=2048
sysctl -w net.core.rmem_default=1048576
sysctl -w net.core.wmem_default=1048576
sysctl -w net.core.rmem_max=16777216
sysctl -w net.core.wmem_max=16777216
sysctl -w net.ipv4.udp_rmem_min=16384
sysctl -w net.ipv4.udp_wmem_min=16384
sysctl -w net.ipv4.tcp_slow_start_after_idle=0
sysctl -w net.ipv4.tcp_autocorking=0
sysctl -w net.ipv4.tcp_notsent_lowat=16384
sysctl -w net.ipv4.tcp_low_latency=1
sysctl -w net.ipv4.tcp_sack=1
sysctl -w net.ipv4.tcp_timestamps=1
sysctl -w net.ipv4.tcp_tw_reuse=1
sysctl -w net.ipv4.tcp_fin_timeout=15
sysctl -w net.ipv4.tcp_rmem="4096 87380 4194304"
sysctl -w net.ipv4.tcp_wmem="4096 65536 4194304"
sysctl -w net.ipv4.neigh.default.base_reachable_time_ms=600000
sysctl -w net.ipv4.neigh.default.gc_stale_time=86400
sysctl -w net.ipv6.neigh.default.base_reachable_time_ms=600000
sysctl -w net.ipv6.neigh.default.gc_stale_time=86400
sysctl -w net.ipv4.ip_no_pmtu_disc=0

# 4. Prevent RILD & Netd CPU Bottleneck (Obsidian Zcore Pattern)
if [ -f /dev/cpuset/system-background/cpus ]; then
    echo 0-6 > /dev/cpuset/system-background/cpus 2>/dev/null || true
fi

# 5. Uclamp Scheduler Latency Sensitivity (Eliminate Thread Wakeup Stutter)
if [ -f /dev/cpuctl/top-app/cpu.uclamp.latency_sensitive ]; then
    echo 1 > /dev/cpuctl/top-app/cpu.uclamp.latency_sensitive 2>/dev/null || true
fi
if [ -f /dev/cpuctl/top-app/cpu.uclamp.min ]; then
    echo 20 > /dev/cpuctl/top-app/cpu.uclamp.min 2>/dev/null || true
fi

# 6. Android Network Settings
settings put global network_recommendations_enabled 0
settings put global mobile_data_always_on 1
cmd wifi force-low-latency-mode enabled 2>/dev/null || true
cmd wifi force-hi-perf-mode enabled 2>/dev/null || true
settings put global wifi_scan_always_enabled 0 2>/dev/null || true
settings put global wifi_sleep_policy 2 2>/dev/null || true
settings put global wifi_power_save 0 2>/dev/null || true

# 7. Interface Queue Tuning (Safe txqueuelen 1000 + Gold Core RPS & XPS)
tune_interfaces() {
    for d in /sys/class/net/rmnet* /sys/class/net/wlan* /sys/class/net/tun*; do
        [ -d "$d" ] || continue
        iface="$(basename "$d")"
        cur_txq="$(cat "$d/tx_queue_len" 2>/dev/null)"
        if [ "$cur_txq" -lt 1000 ]; then
            ifconfig "$iface" txqueuelen 1000 2>/dev/null
        fi
        # RX steering to Gold cores (0x78 = cores 3,4,5,6 on SM8635)
        if [ -f "$d/queues/rx-0/rps_cpus" ]; then
            echo 78 > "$d/queues/rx-0/rps_cpus" 2>/dev/null || true
        fi
        # TX steering to Gold cores
        for tx_q in "$d/queues/tx-"*; do
            [ -f "$tx_q/xps_cpus" ] && echo 78 > "$tx_q/xps_cpus" 2>/dev/null || true
        done
    done
}
tune_interfaces

# 8. Anti-DRX Radio Keep-Warm Daemon (Screen-Aware)
# Only sends 28-byte pulse when screen is awake. Pauses when asleep.
# Never calls ifconfig in loop to avoid queue lock desync.
pacer_loop() {
    while true; do
        if dumpsys power 2>/dev/null | grep -q "mWakefulness=Awake"; then
            ping -i 0.5 -s 0 -q -w 10 1.1.1.1 >/dev/null 2>&1 || sleep 5
        else
            sleep 10
        fi
    done
}

# Run pacer in background
pacer_loop &
